#pragma once

#include "CelluloRobot/src/robot/CelluloRobot.h"
// ROS
#include <ros/ros.h>
#include <std_srvs/Trigger.h>
#include "std_msgs/Empty.h"
#include "std_msgs/Bool.h"
#include "std_msgs/Int8.h"
#include "std_msgs/UInt8.h"
#include "nav_msgs/Path.h"
#include "geometry_msgs/Point.h"
#include "geometry_msgs/Pose2D.h"
#include "geometry_msgs/Vector3.h"
#include "ros_cellulo/cellulo_pose_velocity.h"
#include "ros_cellulo/cellulo_visual_effect.h"
#include "ros_cellulo/CelluloState.h"
#include "ros_cellulo/cellulo_kidnapped_msg.h"
#include "ros_cellulo/cellulo_touch_key.h"
#include "ros_cellulo/cellulo_vibrateOnMotion.h"
#include "ros_cellulo/cellulo_coord.h"
#include "ros_cellulo/cellulo_simpleVibrate.h"


//QT
#include "QObject"

using namespace Cellulo;

namespace ros_cellulo {

/*!
 * Main class for the node to handle the ROS interfacing.
 */
class RosCellulo : CelluloRobot
{
Q_OBJECT

public:
/*!
 * Constructor.
 * @param nodeHandle the ROS node handle, MacAddr the MacAddress of this Cellulo robot
 */
explicit RosCellulo(ros::NodeHandle& nodeHandle,char* MacAddr);


/*!
 * Destructor.
 */
virtual ~RosCellulo();

private:

/*!
 * Reads and verifies the ROS parameters.
 * @return true if successful.
 */
bool readParameters();

/*!
 * ROS topic callback method: Set the pose and velocity
 * @param ros_cellulo_msgs of pose and velocity
 */

void topicCallback_setGoalPose(const cellulo_pose_velocity& message);


/*!
 * ROS topic callback method: Set the pose and velocity
 * @param ros_cellulo_msgs of pose and velocity
 */

void topicCallback_setGoalVelocity(const geometry_msgs::Vector3 &velocity);

/*!
 * ROS topic callback method: set X goal coordinate
 * @param Ros message cellulo_coord msg
 */

void topicCallback_setGoalXCoordinate(const cellulo_coord& message);

/*!
 * ROS topic callback method: set Y goal coordinate
 * @param Ros message cellulo_coord msg
 */

void topicCallback_setGoalYCoordinate(const cellulo_coord& message);

/*!
 * ROS topic callback method: set theta goal coordinate
 * @param Ros message cellulo_coord msg
 */

void topicCallback_setGoalOrientation(const cellulo_coord& message);

/*!
 * ROS topic callback method: Set the visual effect.
 * @param ros_cellulo_msgs of visual effect
 */

void topicCallback_set_Visual_Effect(const cellulo_visual_effect& message);

/*!
 * ROS topic callback method Sets the LED response mode, i.e the LED visual response of the robot to touches
 * @param uint8 LED resposne mode
 */
void topicCallback_setLEDResponseMode(const std_msgs::UInt8 mode);


/*!
 * ROS topic callback method: Resets the Cellulo robot
 * @param empty message
 */

void topicCallback_reset(const std_msgs::Empty message);

/*!
 * ROS topic callback method:follow the received trajectory
 * @param a Ros message Path.
 */

void topicCallback_follow_Trajectory(const nav_msgs::Path &path);



/*!
 * ROS topic callback method: set goal position
 * @param Ros message: Point
 */

void topicCallback_setGoalPosition(const geometry_msgs::Pose2D &position);

/*!
 * ROS topic callback method: Fills the path (attribute of list of points)  if new point is received but previous point tracked is not reached yet.
 * @param Ros message: Point
 */

void topicCallback_fill_Path(const geometry_msgs::Point &point);


/*!
 * ROS topic callback method.
 * Shutdown cellulo
 */

void topicCallback_shutDown(const std_msgs::Empty &empt);

/*!
 * ROS topic callback method
 * Clear Tracking of the robot.
 */

void topicCallback_ClearTracking(const std_msgs::Empty message);

/*!
 * ROS topic callback method
 * Clear Haptic Feedback of the robot.
 */

void topicCallback_ClearHapticFeedback(const std_msgs::Empty message);


/**
 * @brief Constantly vibrates the robot
 *
 * @param iX X intensity, scale is the same as linear velocity
 * @param iY Y intensity, scale is the same as linear velocity
 * @param iTheta Theta intensity, scale is the same as angular velocity
 * @param period Period of vibration in milliseconds, maximum is 0xFFFF
 * @param duration Duration of vibration in milliseconds, maximum is 0xFFFF, 0 for vibrate forever
 */
void topicCallback_simpleVibrate(const cellulo_simpleVibrate &message);

/*!
 * ROS topic callback method
 * Simple Vibrate
 */

void topicCallback_vibrateOnMotion(const cellulo_vibrateOnMotion &message);


/*!
 * ROS topic callback method
 * setGestureEnabled.
 */

void topicCallback_setGestureEnabled(const std_msgs::Bool &message);

/*!
 * ROS topic callback method
 * setCasualBackdriveAssistEnabled
 */
void topicCallback_setCasualBackdriveAssistEnabled(const std_msgs::Bool &message );

/*!
 * ROS service server callback.
 * @param request the request of the service.
 * @param response the provided response.
 * @return true if successful, false otherwise.
 */
bool serviceCallback(CelluloState::Request& request,
                     CelluloState::Response& response);



//! ROS node handle.
ros::NodeHandle& nodeHandle_;


//! ROS topic subscriber.
ros::Subscriber subscriber_VisEff;
ros::Subscriber subscriber_setLEDResponseMode;
ros::Subscriber subscriber_setGoalPose;
ros::Subscriber subscriber_setGoalVelocity;
ros::Subscriber subscriber_setGoalXCoordinate;
ros::Subscriber subscriber_setGoalYCoordinate;
ros::Subscriber subscriber_setGoalOrientation;
ros::Subscriber subscriber_Reset;
ros::Subscriber subscriber_Traj;
ros::Subscriber subscriber_setGoalPosition;
ros::Subscriber subscriber_fillPath;
ros::Subscriber subscriber_shutDown;
ros::Subscriber subscriber_ClearTracking;
ros::Subscriber subscriber_ClearHapticFeedback;
ros::Subscriber subscriber_vibrateOnMotion;
ros::Subscriber subscriber_simpleVibrate;
ros::Subscriber subscriber_setGestureEnabled;
ros::Subscriber subscriber_setCasualBackdriveAssistEnabled;


//! ROS topic names to subscribe to.
std::string subscriberTopic_setGoalPose="setGoalPose";
std::string subscriberTopic_setGoalPosition="setGoalPosition";
std::string subscriberTopic_setGoalVelocity="setGoalVelocity";
std::string subscriberTopic_setGoalXCoordinate="setGoalXCoordinate";
std::string subscriberTopic_setGoalYCoordinate="setGoalYCoordinate";
std::string subscriberTopic_setGoalOrientation="setGoalOrientation";
std::string subscriberTopic_VisEff="Set_Visual_Effect";
std::string subscriberTopic_setLEDResponseMode="setLEDResponseMode";
std::string subscriberTopic_Reset="Reset";
std::string subscriberTopic_Traj="write_traj_back";
std::string subscriberTopic_fillPath="Fill_Path";
std::string subscriberTopic_shutDown="Shutdown";
std::string subscriberTopic_ClearTracking="ClearTracking";
std::string subscriberTopic_ClearHapticFeedback="ClearHapticFeedback";
std::string subscriberTopic_vibrateOnMotion="vibrateOnMotion";
std::string subscriberTopic_simpleVibrate="simpleVibrate";
std::string subscriberTopic_setGestureEnabled="setGestureEnabled";
std::string subscriberTopic_setCasualBackdriveAssistEnabled="setCasualBackdriveAssistEnabled";

//! ROS topic publisher.
ros::Publisher publisher_TouchKey;
ros::Publisher publisher_LongTouchKey;
ros::Publisher publisher_Kidnapped;
ros::Publisher publisher_ConnectionStatus;
ros::Publisher publisher_LocalAdapterMacAddress;
ros::Publisher publisher_autoConnect;
ros::Publisher publisher_macAddress;
ros::Publisher publisher_BatteryState;
ros::Publisher publisher_Gesture;
ros::Publisher publisher_lastTimestamp;
ros::Publisher publisher_framerate;
ros::Publisher publisher_cameraImageProgress;
ros::Publisher publisher_vx;
ros::Publisher publisher_vy;
ros::Publisher publisher_w;
ros::Publisher publisher_poseVelControlEnabled;
ros::Publisher publisher_poseVelControlPeriod;
ros::Publisher publisher_marker_robot;
ros::Publisher publisher_marker_traj;
ros::Publisher publisher_marker_traj2;
ros::Publisher publisher_destination_reached;


//! ROS topic name to publish to.
std::string publisherTopic_TouchKey="TouchKey";
std::string publisherTopic_LongTouchKey="LongTouchKey";
std::string publisherTopic_Kidnapped="Kidnapped";
std::string publisherTopic_ConnectStatus="ConnectionStatus";
std::string publisherTopic_LocalAdapterAdress="LocalAdapterAdress";
std::string publisherTopic_autoConnect="autoConnect";
std::string publisherTopic_macAddress="macAddress";
std::string publisherTopic_BatteryState="BatteryState";
std::string publisherTopic_Gesture="Gesture";
std::string publisherTopic_lastTimestamp="lastTimestamp";
std::string publisherTopic_framerate="framerate";
std::string publisherTopic_cameraImageProgress="cameraImageProgress";
std::string publisherTopic_vx="Vx";
std::string publisherTopic_vy="Vy";
std::string publisherTopic_w="w";
std::string publisherTopic_poseVelControlEnabled="poseVelControlEnable";
std::string publisherTopic_poseVelControlPeriod="poseVelControlPeriod";
std::string publisherTopic_marker_robot="visualization_marker_robot";
std::string publisherTopic_marker_traj="visualization_marker_traj";
std::string publisherTopic_destination_reached="destination_reached";



//! ROS service server.
ros::ServiceServer serviceServer_;

double scale=0.001;
bool repeat=1;
QList<QVector2D> mypath;
QVector2D my_tracked_position=QVector2D(-1,-1);


int f=0;         // counter for the ids for the markers of the trajectory of cellulo (in rviz)

QColor color = QColor("white");         // color of Cellulo leds

//function to calculate the norm of a vector (x,y)
double norm(double x,double y);

//Publishers defined as slots

public slots:
void Publish_Pose();
void Publish_LongKeys();
void Publish_Keys();
void Publish_Kidnapped();
void Publish_ConnectionStatus();
void Publish_LocalAdapterMacAddress();
void Publish_autoConnect();
void Publish_macAddress();
void Publisher_BatteryState();
void Publish_Gesture();
void Publish_lastTimestamp();
void Publish_framerate();
void Publish_cameraImageProgress();
void Publish_Vx();
void Publish_Vy();
void Publish_w();
void Publish_poseVelControlEnable();
void Publish_poseVelControlPeriod();
void Publish_destinationReached();
bool reset_robot();
void go_to_next_point();
void keep_track();


signals:
void ready_for_next_pose();        //emitted when distance to tracked position is less then 23 mm

public:
int reset_counter=0;         //reset_counter to resend the









};
} /* namespace */
